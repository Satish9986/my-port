---
name: "Feature request \U0001F4A1"
about: Suggest an idea for this project
title: ''
labels: ''
assignees: ''

---

## Summary
A brief explanation of the feature.

### What's new?
If the proposal involves a new component or a redesign of a previous component. 

### Motivation
Why are we doing this? What use cases does it support? What is the expected outcome?

### Additional context
Add any other context or screenshots about the feature request here.
